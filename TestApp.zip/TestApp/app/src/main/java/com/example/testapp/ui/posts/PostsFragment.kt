package com.example.testapp.ui.posts

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testapp.R
import com.example.testapp.model.apiresponses.PostApiResponse

class PostsFragment : Fragment() {


    private lateinit var postsViewModel:  PostsViewModel
    private lateinit var ctxt: Context
    private lateinit var listView : RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        postsViewModel = ViewModelProvider(this).get(PostsViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_posts, container, false)
        listView = root.findViewById(R.id.posts_list)
        postsViewModel.getPosts()

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        postsViewModel.response.observe(viewLifecycleOwner, Observer {
            showPosts(it)
        })
    }

    private fun showPosts(list: ArrayList<PostApiResponse>?) {
        if (!list.isNullOrEmpty()) {
            val adapter = PostsAdapter(ctxt,list )
            listView.layoutManager = LinearLayoutManager(ctxt)
            listView.adapter = adapter
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        ctxt = context
    }
}