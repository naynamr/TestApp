package com.example.testapp.ui.photos

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.testapp.model.apiresponses.PhotoApiResponse
import com.example.testapp.network.Api
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception

class PhotoViewModel : ViewModel() {


    private val _response = MutableLiveData<ArrayList<PhotoApiResponse>>()
    val response: LiveData<ArrayList<PhotoApiResponse>>
        get() = _response


    /**
     *  Get Photo Api
     */
    fun getPhotos() {
        try {

            Api.retrofitService.getPhotos(            )
                .enqueue(object : Callback<ArrayList<PhotoApiResponse>> {
                    override fun onFailure(call: Call<ArrayList<PhotoApiResponse>>, t: Throwable) {
                        _response.value = null
                    }

                    override fun onResponse(
                        call: Call<ArrayList<PhotoApiResponse>>,
                        response: Response<ArrayList<PhotoApiResponse>>
                    ) {
                        if (response.isSuccessful) {
                            _response.value = response.body()
                        } else {
                            _response.value = null
                        }
                    }
                })

        } catch (e: Exception) {
            _response.value = null
        }

    }


}