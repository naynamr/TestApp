package com.example.testapp.model.apiresponses

data class PhotoApiResponse(
    val albumId: Int,
    val id: Int,
    val title: String,
    val url: String,
    val thumbnailUrl: String
)