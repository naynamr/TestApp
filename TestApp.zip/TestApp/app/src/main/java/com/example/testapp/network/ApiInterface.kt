package com.example.testapp.network

import com.example.testapp.model.ApiConstants
import com.example.testapp.model.apiresponses.PhotoApiResponse
import com.example.testapp.model.apiresponses.PostApiResponse
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {

//    //@FormUrlEncoded
//    @POST(WebConstants.login)
//    fun login(
//        @Body data: RegisterRequest
//    ): Call<RegisterResponse>
//
//    @FormUrlEncoded
//    @POST(WebConstants.device_token)
//    fun sendFcmToken(
//        @Field("deviceToken", encoded = true) deviceToken: String
//    ): Call<DefaultApiResponse>

    @GET(ApiConstants.photos)
    fun getPhotos(): Call<ArrayList<PhotoApiResponse>>

    @GET(ApiConstants.posts)
    fun getPosts(): Call<ArrayList<PostApiResponse>>


}