package com.example.testapp.ui.photos

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testapp.R
import com.example.testapp.model.apiresponses.PhotoApiResponse

class PhotoFragment : Fragment() {

    private lateinit var photoViewModel: PhotoViewModel
    private lateinit var ctxt: Context
    private lateinit var listView : RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        photoViewModel = ViewModelProvider(this).get(PhotoViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_photos, container, false)
        listView = root.findViewById(R.id.photo_list)
        photoViewModel.getPhotos()

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        photoViewModel.response.observe(viewLifecycleOwner, Observer {
            showPhotos(it)
        })
    }

    private fun showPhotos(list: ArrayList<PhotoApiResponse>?) {
        if (!list.isNullOrEmpty()) {
//            var a = ArrayList<PhotoApiResponse>()
//            list.forEach {
//
//                a.add(it)
//            }


            val adapter = PhotoAdapter(ctxt,list )
            listView.layoutManager = LinearLayoutManager(ctxt)
            listView.adapter = adapter
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        ctxt = context
    }
}