package com.example.testapp.model

object ApiConstants {

    const val photos = "photos"
    const val posts = "posts"
}