package com.example.testapp.model.apiresponses

data class PostApiResponse(
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)