package com.example.testapp.ui.posts

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.testapp.BR
import com.example.testapp.R
import com.example.testapp.databinding.PostsListBinding
import com.example.testapp.model.apiresponses.PostApiResponse
import kotlin.collections.ArrayList

class PostsAdapter(
    private val mContext: Context,
    private var list: ArrayList<PostApiResponse>
) :
    RecyclerView.Adapter<PostsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val binding: PostsListBinding = DataBindingUtil.inflate(
            LayoutInflater.from(mContext),
            R.layout.posts_list,
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        if (!list.isNullOrEmpty())
            return list.size
        else return 0
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    class ViewHolder(val binding: PostsListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: Any) {
            binding.setVariable(BR.PostData, data)
            binding.executePendingBindings()
        }
    }

}