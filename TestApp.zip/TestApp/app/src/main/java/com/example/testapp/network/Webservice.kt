package com.example.testapp.network

import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


const val BASE_URL = "https://jsonplaceholder.typicode.com/"


object Api {
    val retrofitService: ApiInterface by lazy {
        retrofitService().create(ApiInterface::class.java)
    }
}

/**
 *  Retrofit
 */
fun retrofitService(): Retrofit {
    return Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(getUnsafeOkHttpClient())
        .addConverterFactory(GsonConverterFactory.create())
        .build()
}

/**
 * OkHttpClient
 */

private fun getUnsafeOkHttpClient(): OkHttpClient {
    val dispatcher = Dispatcher()
    dispatcher.maxRequests = 1
    val interceptor = HttpLoggingInterceptor()
    interceptor.level = HttpLoggingInterceptor.Level.HEADERS
    interceptor.level = HttpLoggingInterceptor.Level.BODY
    val builder = OkHttpClient.Builder()
    builder.addInterceptor(interceptor)
        //.dispatcher(dispatcher)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)

    return builder.build()
}

