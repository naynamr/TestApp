package com.example.testapp.ui.photos

import android.content.Context

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

import com.example.testapp.BR
import com.example.testapp.R
import com.example.testapp.databinding.PhotoListBinding
import com.example.testapp.model.apiresponses.PhotoApiResponse



class PhotoAdapter(
    private val mContext: Context,
    private var list: ArrayList<PhotoApiResponse>
) :
    RecyclerView.Adapter<PhotoAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val binding: PhotoListBinding = DataBindingUtil.inflate(
            LayoutInflater.from(mContext),
            R.layout.photo_list,
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        if (!list.isNullOrEmpty())
            return list.size
        else return 0
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.bind(list[position])

        Glide.with(mContext)
            .load(list[position].thumbnailUrl)
            .into(holder.binding.image)


    }

    class ViewHolder(val binding: PhotoListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: Any) {
            binding.setVariable(BR.PhotoData, data)
            binding.executePendingBindings()
        }
    }

}