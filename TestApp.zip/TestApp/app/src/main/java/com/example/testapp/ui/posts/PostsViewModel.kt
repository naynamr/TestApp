package com.example.testapp.ui.posts

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.testapp.model.apiresponses.PostApiResponse
import com.example.testapp.network.Api
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception

class PostsViewModel : ViewModel() {

    private val _response = MutableLiveData<ArrayList<PostApiResponse>>()
    val response: LiveData<ArrayList<PostApiResponse>>
        get() = _response


    /**
     *  Get Post Api
     */
    fun getPosts() {
        try {
            Api.retrofitService.getPosts()
                .enqueue(object : Callback<ArrayList<PostApiResponse>> {
                    override fun onFailure(call: Call<ArrayList<PostApiResponse>>, t: Throwable) {
                        _response.value = null
                    }

                    override fun onResponse(
                        call: Call<ArrayList<PostApiResponse>>,
                        response: Response<ArrayList<PostApiResponse>>
                    ) {
                        if (response.isSuccessful) {
                            _response.value = response.body()
                        } else {
                            _response.value = null
                        }
                    }
                })

        } catch (e: Exception) {
            _response.value = null
        }

    }
}